import React, { useState } from 'react';
import { MessageCircle, X } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

export const Chatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const whatsappNumber = '+254111800542'; // Replace with your WhatsApp business number
  const whatsappMessage = encodeURIComponent('Hello! I have a question about CYA AIC Juja.');
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${whatsappMessage}`;

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-blue-600 text-white px-6 py-4 rounded-full shadow-lg hover:bg-blue-700 transition-colors z-50 flex items-center justify-center"
        aria-label="Chat on WhatsApp"
      >
        <MessageCircle size={24} />
        <span className="ml-2 hidden md:inline">Chat with Us</span>
      </button>

      {isOpen && (
        <div className="fixed bottom-24 right-6 w-96 bg-white rounded-lg shadow-xl z-50 flex flex-col">
          <div className="p-4 bg-blue-600 text-white rounded-t-lg flex justify-between items-center">
            <h3 className="font-semibold">Chat with Us on WhatsApp</h3>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:text-gray-200"
              aria-label="Close chat"
            >
              <X size={20} />
            </button>
          </div>

          <div className="p-6 text-center">
            <p className="mb-4">Scan the QR code or click the button below to chat with us on WhatsApp:</p>
            
            <div className="flex justify-center mb-6">
              <QRCodeSVG value={whatsappUrl} size={200} />
            </div>

            <a
              href={whatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-green-500 text-white px-6 py-3 rounded-lg font-semibold hover:bg-green-600 transition-colors"
            >
              Open WhatsApp Chat
            </a>

            <p className="mt-4 text-sm text-gray-600">
              Our team is available Monday to Friday, 9:00 AM to 5:00 PM
            </p>
          </div>
        </div>
      )}
    </>
  );
};