import React, { useState } from "react";
import { Menu, X } from 'lucide-react';
import { Chatbot } from './components/Chatbot';

const App: React.FC = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <div className="min-h-screen bg-gray-100 text-gray-900 relative">
      {/* Navigation Bar */}
      <nav className="bg-blue-600 p-4 text-white">
        <div className="flex justify-between items-center">
          <h1 className="text-xl font-bold">CYA AIC Juja</h1>
          
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden"
            onClick={toggleMenu}
            aria-label="Toggle menu"
          >
            {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {/* Desktop Navigation */}
          <ul className="hidden md:flex space-x-4">
            <li><a href="#about">About</a></li>
            <li><a href="#events">Events</a></li>
            <li><a href="#gallery">Gallery</a></li>
            <li><a href="#contact">Contact</a></li>
          </ul>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <ul className="md:hidden pt-4 space-y-2">
            <li><a href="#about" onClick={toggleMenu} className="block py-2">About</a></li>
            <li><a href="#events" onClick={toggleMenu} className="block py-2">Events</a></li>
            <li><a href="#gallery" onClick={toggleMenu} className="block py-2">Gallery</a></li>
            <li><a href="#contact" onClick={toggleMenu} className="block py-2">Contact</a></li>
          </ul>
        )}
      </nav>
      
      {/* Hero Section */}
      <header className="bg-blue-500 text-white text-center py-20">
        <h2 className="text-4xl font-bold">Welcome to CYA AIC Juja Events</h2>
        <p className="mt-4 text-lg">Join us in growing together in faith, fellowship, and service.</p>
        <a href="#events" className="mt-6 inline-block bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold">Explore Events</a>
      </header>
      
      {/* About Section */}
      <section id="about" className="p-8 bg-white text-center">
        <h3 className="text-2xl font-bold">About Us</h3>
        <p className="mt-4">CYA AIC Juja is a community of young believers dedicated to faith, leadership, and service. Our events aim to inspire and equip youth for spiritual growth.</p>
      </section>
      
      {/* Events Section */}
      <section id="events" className="p-8 bg-gray-200 text-center">
        <h3 className="text-2xl font-bold mb-8">Our Events</h3>
        
        {/* Upcoming Events */}
        <div className="mb-12">
          <h4 className="text-xl font-semibold mb-6">Upcoming Special Events</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow">
              <h4 className="text-lg font-semibold">Youth Hike</h4>
              <p className="mt-2 text-sm">Date: April 12, 2025 | Venue: TBD</p>
              <p className="mt-2 text-sm text-gray-600">Join us for an exciting adventure and fellowship in nature.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h4 className="text-lg font-semibold">CYA Weekend Challenge</h4>
              <p className="mt-2 text-sm">Date: April 24-27, 2025 | Venue: AIC Juja</p>
              <p className="mt-2 text-sm text-gray-600">A weekend of spiritual growth, fellowship, and challenges.</p>
            </div>
          </div>
        </div>
        
        {/* Regular Events */}
        <div>
          <h4 className="text-xl font-semibold mb-6">Regular Events</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl mx-auto">
            <div className="bg-white p-6 rounded-lg shadow">
              <h4 className="text-lg font-semibold">Youth Fellowship</h4>
              <p className="mt-2 text-sm">Every Tuesday | 6:30 PM - 7:30 PM</p>
              <p className="mt-2 text-sm text-gray-600">Weekly gathering for worship, Bible study, and fellowship.</p>
            </div>
            <div className="bg-white p-6 rounded-lg shadow">
              <h4 className="text-lg font-semibold">Youth Meeting</h4>
              <p className="mt-2 text-sm">Every Sunday | After Service</p>
              <p className="mt-2 text-sm text-gray-600">Regular meeting for youth after the main church service.</p>
            </div>
          </div>
        </div>
      </section>
      
      {/* Gallery Section */}
      <section id="gallery" className="p-8 bg-white text-center">
        <h3 className="text-2xl font-bold">Gallery</h3>
        <p className="mt-4">Check out highlights from our past events.</p>
        {/* Add images here */}
      </section>
      
      {/* Contact Section */}
      <section id="contact" className="p-8 bg-gray-200 text-center">
        <h3 className="text-2xl font-bold">Contact Us</h3>
        <p className="mt-4">Have questions? Reach out to us!</p>
        <form className="mt-6 space-y-4 max-w-lg mx-auto" action="https://docs.google.com/forms/d/e/1FAIpQLSc40XNrVehnHW7dxA8YjuApJgqRLPfW3nKq131dP4R5cCxdFA/formResponse" method="POST" target="_blank">
          <input type="text" name="entry.2005620554" placeholder="Your Name" className="p-2 w-full border rounded" required />
          <input type="email" name="entry.1045781291" placeholder="Your Email" className="p-2 w-full border rounded" required />
          <textarea name="entry.839337160" placeholder="Your Message" className="p-2 w-full border rounded h-32" required></textarea>
          <button type="submit" className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700 transition-colors">Send Message</button>
        </form>
      </section>
      
      {/* Join Us Section */}
      <section id="join-us" className="p-8 bg-white text-center">
        <h3 className="text-2xl font-bold">Join Us</h3>
        <p className="mt-4">Become a part of our community by filling out our membership form.</p>
        <a 
          href="https://docs.google.com/forms/d/e/1FAIpQLSc40XNrVehnHW7dxA8YjuApJgqRLPfW3nKq131dP4R5cCxdFA/viewform"
          target="_blank"
          rel="noopener noreferrer"
          className="mt-6 inline-block bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-colors"
        >
          Join CYA AIC Juja
        </a>
      </section>
      
      {/* Footer */}
      <footer className="bg-blue-600 text-white text-center p-4">
        &copy; 2025 CYA AIC Juja. All Rights Reserved.
      </footer>

      {/* AI Chatbot */}
      <Chatbot />
    </div>
  );
};

export default App;